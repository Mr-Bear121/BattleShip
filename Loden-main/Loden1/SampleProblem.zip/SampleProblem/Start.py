import sys
import os
import subprocess



if __name__ == '__main__':

    while True:
        #it says it cannot find abstract base class in server.py. the import is: from Abstractions.Client_Server.ABCServer import ABCServer
        process=subprocess.Popen(f'python Server/Server.py')